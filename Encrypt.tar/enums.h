
//the entire purpose of this file is to make distinguishing what encryption we are doing easier to understand

class enums {
    public:
        enum block_stream {BLOCK, STREAM};
        enum encdec {ENCRYPT, DECRYPT};
};
